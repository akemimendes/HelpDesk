package com.curso.udemy.helpdesk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelpdeskApplicationTests {

	@Test
	void contextLoads() {
	}

}
